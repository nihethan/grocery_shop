package com.furniture.groceryshop.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.furniture.groceryshop.entity.OrderEntity;

public interface OrderRepository extends JpaRepository<OrderEntity,String> {
    
}

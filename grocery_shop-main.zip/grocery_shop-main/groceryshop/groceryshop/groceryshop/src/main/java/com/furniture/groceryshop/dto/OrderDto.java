package com.furniture.groceryshop.dto;

import java.time.LocalDate;
import java.util.List;

import com.furniture.groceryshop.entity.CustomerDetailsEntity;
import com.furniture.groceryshop.entity.ProductEntity;

import lombok.Data;
@Data
public class OrderDto {
	private String orderId;
	private LocalDate dateOfBirth;
	private List<ProductDto>  product; 
	private CustomerDetailsDto customerDetails;

}

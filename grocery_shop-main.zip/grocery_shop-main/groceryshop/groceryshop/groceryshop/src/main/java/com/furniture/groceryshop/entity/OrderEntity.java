package com.furniture.groceryshop.entity;

import java.time.LocalDate;
import java.util.List;

import com.furniture.groceryshop.dto.OrderDto;
//im//port com.sun.tools.javac.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
//import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Data
@Table(name="order_table")
public class OrderEntity {
	@Id
	@Column(name="order_id")
	private String orderId;
	
	@Column(name="order_date")
	private LocalDate dateOfBirth;
	
	@OneToMany(mappedBy="product",cascade = CascadeType.ALL)
	//@JoinColumn(name = "product_id")
	 private List<ProductEntity> product;
	
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "customer_id")  
    private CustomerDetailsEntity customerDetails;
   
}

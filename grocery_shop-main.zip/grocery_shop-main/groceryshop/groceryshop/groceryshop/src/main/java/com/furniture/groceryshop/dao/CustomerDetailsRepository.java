package com.furniture.groceryshop.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.furniture.groceryshop.entity.CustomerDetailsEntity;

public interface CustomerDetailsRepository extends JpaRepository<CustomerDetailsEntity,String> {

}

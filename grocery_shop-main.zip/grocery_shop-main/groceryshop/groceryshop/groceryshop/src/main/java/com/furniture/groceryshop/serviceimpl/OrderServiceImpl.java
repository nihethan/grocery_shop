package com.furniture.groceryshop.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.furniture.groceryshop.dao.CustomerDetailsRepository;
import com.furniture.groceryshop.dao.OrderRepository;
import com.furniture.groceryshop.dao.ProductRepository;
//import com.furniture.groceryshop.dto.CustomerDetailsDto;
import com.furniture.groceryshop.dto.OrderDto;
import com.furniture.groceryshop.dto.ProductDto;
import com.furniture.groceryshop.dto.ResponseDto;
import com.furniture.groceryshop.entity.CustomerDetailsEntity;
//import com.furniture.groceryshop.entity.CustomerDetailsEntity;
import com.furniture.groceryshop.entity.OrderEntity;
import com.furniture.groceryshop.entity.ProductEntity;
import com.furniture.groceryshop.service.OrderService;

import lombok.Data;
@Data
public class OrderServiceImpl implements OrderService {
private final OrderRepository orderRepository;
private final ProductRepository productRepository;
private final CustomerDetailsRepository customerDetailsRepository;
	
	@Override
	public ResponseDto createOrder(OrderDto orderDto) {
		// TODO Auto-generated method stub
		try{
			ResponseDto response=new ResponseDto();
			OrderEntity order=new OrderEntity();
			if(orderDto.getOrderId()==null) {
				Optional<OrderEntity> optionOrder=orderRepository.findById(orderDto.getOrderId());
				if(!optionOrder.isEmpty()) {
					order=optionOrder.get();
					order.setOrderId(orderDto.getOrderId());
					order.setDateOfBirth(orderDto.getDateOfBirth());
//					
					 List<ProductEntity> productEntities = new ArrayList<>();
			            for (ProductDto productDto : orderDto.getProduct()) {
			                ProductEntity productEntity = new ProductEntity();
			                productEntity.setProductId(productDto.getProductId());
			                productEntity.setProductName(productDto.getProductName());
			                // Set additional properties from ProductDto
			                productEntities.add(productEntity);
			            }
			            order.setProduct(productEntities);

			            // Convert and set CustomerDetailsEntity list
//			            List<CustomerDetailsEntity> customerDetailsEntities = new ArrayList<>();
//			            for (CustomerDetailsDto customerDto : orderDto.getCustomerDetails()) {
//			                CustomerDetailsEntity customerEntity = new CustomerDetailsEntity();
//			                customerEntity.setCustomerId(customerDto.getCustomerId());
//			                customerEntity.setCustomerName(customerDto.getCustomerName());
//			                // Set additional properties from CustomerDetailsDto
//			                customerDetailsEntities.add(customerEntity);
//			            }
//			            order.setCustomerdetails(customerDetailsEntities);

			       
			            CustomerDetailsEntity customer = new CustomerDetailsEntity();
			            customer.setCustomerId(orderDto.getCustomerDetails().getCustomerAddress());
			          //  customer.setCustomerName(orderDto.getCustomerDetails().getCustomerName());
			            order.setCustomerDetails(customer);

			            // Save the OrderEntity (which will also save the CustomerDetailsEntity due to CascadeType.ALL)
			            orderRepository.save(order);
                        
			            // Prepare success response
			            response.setMessage("Order created successfully");
			  
			}
		}}
		catch(Exception e) {
			throw e;
		}
		return null;
	}

}

package com.furniture.groceryshop.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.furniture.groceryshop.dto.OrderDto;
import com.furniture.groceryshop.dto.ResponseDto;
import com.furniture.groceryshop.service.OrderService;

import lombok.Data;

@RestController
@RequestMapping("api")
@Data

public class OrderController {
  private final OrderService orderService;
  
  public  ResponseEntity<ResponseDto> createOrder(@RequestBody OrderDto orderDto){
	return ResponseEntity.ok(orderService.createOrder(orderDto));
	  
  }
}

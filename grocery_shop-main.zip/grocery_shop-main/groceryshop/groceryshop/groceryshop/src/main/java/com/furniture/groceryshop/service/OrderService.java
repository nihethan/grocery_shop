package com.furniture.groceryshop.service;

import com.furniture.groceryshop.dto.OrderDto;
import com.furniture.groceryshop.dto.ResponseDto;

public interface OrderService {

	ResponseDto createOrder(OrderDto orderDto);

}

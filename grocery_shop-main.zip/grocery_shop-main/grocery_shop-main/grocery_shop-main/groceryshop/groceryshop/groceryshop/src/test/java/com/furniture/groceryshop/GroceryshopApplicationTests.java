package com.furniture.groceryshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GroceryshopApplicationTests {

	@Test
	void contextLoads() {
	}

}

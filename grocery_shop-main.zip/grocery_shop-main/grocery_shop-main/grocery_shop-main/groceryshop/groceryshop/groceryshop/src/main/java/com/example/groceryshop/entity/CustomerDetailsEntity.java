package com.example.groceryshop.entity;

import org.hibernate.annotations.UuidGenerator;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name="customer_details")
@Data
public class CustomerDetailsEntity {
	@Column(name="customer_id")
	@Id
	@UuidGenerator
	  private String customerId;
	@Column(name="customer_name")
	   private String customerName;
	@Column(name="customer_mobile_number")
	   private String customerMobileNumber;
	@Column(name="customer_email")
	   private String customerEmail;
	@Column(name="customer_address")
	   private String customerAddress;
//	@OneToOne(mappedBy="customer_id",cascade=CascadeType.ALL)
//    private OrderEntity orderEntity;
//	
}

package com.example.groceryshop.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.example.groceryshop.dao.CustomerDetailsRepository;
import com.example.groceryshop.dto.CustomerDetailsDto;
import com.example.groceryshop.dto.ResponseDto;
import com.example.groceryshop.entity.CustomerDetailsEntity;
import com.example.groceryshop.service.CustomerDetailsService;

import lombok.Data;
@Service
@Data
public class CustomerDetailsServiceImpl implements CustomerDetailsService {

private final CustomerDetailsRepository customerDetailsRepository;
	
	@Override
	public ResponseDto createCustomerDetails(CustomerDetailsDto customerDetailsDto) {
		// TODO Auto-generated method stub
		ResponseDto responseDto=new ResponseDto();
		try {
			
			CustomerDetailsEntity customerDetails=new CustomerDetailsEntity();
			if(customerDetailsDto.getCustomerId()!=null) {
				Optional<CustomerDetailsEntity> optionCustomerDetails=customerDetailsRepository.findById(customerDetailsDto.getCustomerId());
				if(optionCustomerDetails.isPresent()) {
					customerDetails=optionCustomerDetails.get();
					customerDetails.setCustomerName(customerDetailsDto.getCustomerName());
					customerDetails.setCustomerMobileNumber(customerDetailsDto.getCustomerMobileNumber());
					customerDetails.setCustomerEmail(customerDetailsDto.getCustomerEmail());
					customerDetails.setCustomerAddress(customerDetailsDto.getCustomerAddress());
					
					
				}
			}
			else {
				//System.out.print(customerDetailsDto.getCustomerName());
				customerDetails.setCustomerName(customerDetailsDto.getCustomerName());
				customerDetails.setCustomerMobileNumber(customerDetailsDto.getCustomerMobileNumber());
				customerDetails.setCustomerEmail(customerDetailsDto.getCustomerEmail());
				customerDetails.setCustomerAddress(customerDetailsDto.getCustomerAddress());
				
				
			}
		customerDetailsRepository.save(customerDetails);
			responseDto.setMessage("Add the customer Details in customer Table");
			responseDto.setStatus(200);
			return responseDto;
		}
		catch(Exception e) {
			throw e;
		}
		
	}



	@Override
	public CustomerDetailsDto getCustomerDetailsById(String customerId) {
		// TODO Auto-generated method stub
		CustomerDetailsDto customerDto=new CustomerDetailsDto();
		try {
			CustomerDetailsEntity customerDetails=new CustomerDetailsEntity();
				Optional<CustomerDetailsEntity> optionCustomer =customerDetailsRepository.findById(customerId);
			    customerDetails=optionCustomer.get();
			    customerDto.setCustomerId(customerDetails.getCustomerId());
			    customerDto.setCustomerName(customerDetails.getCustomerName());
			    customerDto.setCustomerMobileNumber(customerDetails.getCustomerMobileNumber());
			    customerDto.setCustomerEmail(customerDetails.getCustomerEmail());
			    customerDto.setCustomerAddress(customerDetails.getCustomerAddress());
		}
		catch(Exception e) {
			throw e;
		}
		return customerDto;
	}



	@Override
	public List<CustomerDetailsDto> getCustomerAllDetails() {
		
		try {
			List<CustomerDetailsDto> dtoList =new ArrayList<>();
			List<CustomerDetailsEntity> customerDetails=customerDetailsRepository.findAll();
			
			customerDetails.forEach(details -> {

				CustomerDetailsDto customerDto=new CustomerDetailsDto();
				customerDto.setCustomerId(details.getCustomerId());
				customerDto.setCustomerName(details.getCustomerName());
				customerDto.setCustomerMobileNumber(details.getCustomerMobileNumber());
				customerDto.setCustomerEmail(details.getCustomerEmail());
				customerDto.setCustomerAddress(details.getCustomerAddress());
				dtoList.add(customerDto);

			});
			return dtoList;
		}
		catch(Exception e) {
			throw e;
		}
		// TODO Auto-generated method stub
		
	}



	@Override
	public ResponseDto deleteCustomerDetailsById(String customerId) {
		// TODO Auto-generated method stub
		ResponseDto response = new ResponseDto();

		try {

			if (customerDetailsRepository.existsById(customerId)) {
				customerDetailsRepository.deleteById(customerId);
				response.setMessage("DELETE SUCCESFULLY");
				return response;
			}

			response.setMessage("STUDENT ID NOT FOUND");

		} catch (Exception e) {
			response.setMessage("FAILED");
			throw e;
		}
		return null;
	}

}

package com.example.groceryshop.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.groceryshop.entity.OrderViewEntity;
import com.example.groceryshop.entity.ProductEntity;

public interface ProductRepository extends JpaRepository<ProductEntity,String> {

	@Query(value="SELECT * FROM product WHERE product_name=:productName",nativeQuery=true)
	//public List<OrderViewEntity> getOrderViewTableElementById(@Param("orderId") String orderId);
	public ProductEntity findByName(@Param("productName") String productName);
	;
	@Query(value="SELECT COUNT(*)>0 FROM product WHERE LOWER(TRIM(product_name))=LOWER(TRIM(:productName))", nativeQuery=true)
	public boolean existByProductName(@Param("productName") String productName);

}

package com.example.groceryshop.service;

import java.util.List;

import com.example.groceryshop.dto.CustomerDetailsDto;
import com.example.groceryshop.dto.ResponseDto;

public interface CustomerDetailsService {

	ResponseDto createCustomerDetails(CustomerDetailsDto customerDetailsDto);

	CustomerDetailsDto getCustomerDetailsById(String customerId);
	
	CustomerDetailsDto getCustomerDetailsByMail(String customerEmail);

	List<CustomerDetailsDto> getCustomerAllDetails();

	ResponseDto deleteCustomerDetailsById(String customerId);

	ResponseDto ServicedeleteAllCustomerDetails();

	boolean checkProductExists(String customerEmail);

}

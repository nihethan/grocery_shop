package com.example.groceryshop.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.groceryshop.entity.OrderViewEntity;

public interface OrderViewRepository extends JpaRepository<OrderViewEntity,String> {

}

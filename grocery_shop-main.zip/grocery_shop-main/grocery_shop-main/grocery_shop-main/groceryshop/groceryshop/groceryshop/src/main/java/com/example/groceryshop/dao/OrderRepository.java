package com.example.groceryshop.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.groceryshop.entity.OrderEntity;

public interface OrderRepository extends JpaRepository<OrderEntity,String> {
    
}

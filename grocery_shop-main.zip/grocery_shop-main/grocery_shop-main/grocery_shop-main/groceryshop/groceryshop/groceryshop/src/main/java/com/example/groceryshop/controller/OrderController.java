package com.example.groceryshop.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.groceryshop.dto.OrderDto;
import com.example.groceryshop.dto.ResponseDto;
import com.example.groceryshop.service.OrderService;

import lombok.Data;

@RestController
@RequestMapping("/api")
@Data
public class OrderController {
  private final OrderService orderService;
  @PostMapping("/order")
  public  ResponseEntity<ResponseDto> createOrder(@RequestBody OrderDto orderDto){
	return ResponseEntity.ok(orderService.createOrder(orderDto));}

  @DeleteMapping("/order")
  public ResponseEntity<ResponseDto> deleteOrder(@RequestParam("orderId") String orderId,@RequestParam ("orderViewId") String orderViewId){
	return ResponseEntity.ok(orderService.deleteOrder(orderId,orderViewId));
	  
  }
  
  @GetMapping("/order")
	  public ResponseEntity<OrderDto> getById(@RequestParam("orderId") String orderId){
		return ResponseEntity.ok(orderService.getById(orderId));
		  
	  
  }
  
}

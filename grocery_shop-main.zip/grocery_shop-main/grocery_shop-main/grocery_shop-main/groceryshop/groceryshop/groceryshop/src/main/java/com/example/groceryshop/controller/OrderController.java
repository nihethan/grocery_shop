package com.example.groceryshop.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.groceryshop.dto.OrderDto;
import com.example.groceryshop.dto.ResponseDto;
import com.example.groceryshop.dto.ViewOrderDto;
import com.example.groceryshop.service.OrderService;

import lombok.Data;

@RestController
@RequestMapping("/api")
@CrossOrigin( origins="*")
@Data
public class OrderController {
  private final OrderService orderService;
  @PostMapping("/order")
  public  ResponseEntity<ResponseDto> createOrder(@RequestBody OrderDto orderDto){
	return ResponseEntity.ok(orderService.createOrder(orderDto));}

  @DeleteMapping("/order")
  public ResponseEntity<ResponseDto> deleteOrder(@RequestParam("orderId") String orderId){
	return ResponseEntity.ok(orderService.deleteOrder(orderId));
	  
  }
  
  @GetMapping("/order")
  public ResponseEntity<OrderDto> getOrderById(@RequestParam("orderId") String orderId){
		return ResponseEntity.ok(orderService.getOrderById(orderId));
}
  
  @GetMapping("/orderview")
	  public ResponseEntity<List<ViewOrderDto>> getById(@RequestParam("orderId") String orderId){
		return ResponseEntity.ok(orderService.getById(orderId));
  }
  
  


@DeleteMapping("/deleteorder")
public ResponseEntity<ResponseDto> deleteAllOrder(){
	return ResponseEntity.ok(orderService.deleteAllOrder());
}
}

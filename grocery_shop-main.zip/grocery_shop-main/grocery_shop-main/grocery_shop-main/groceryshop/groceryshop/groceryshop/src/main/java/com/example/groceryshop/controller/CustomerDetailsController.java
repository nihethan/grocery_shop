package com.example.groceryshop.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.groceryshop.dto.CustomerDetailsDto;
import com.example.groceryshop.dto.ResponseDto;
import com.example.groceryshop.service.CustomerDetailsService;
import com.example.groceryshop.service.ProductService;

import lombok.Data;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class CustomerDetailsController {
   private final CustomerDetailsService customerDetailsService;
   
   @PostMapping("/customer")
   public ResponseEntity<ResponseDto> createCustomerDetails(@RequestBody CustomerDetailsDto customerDetailsDto){
	   return ResponseEntity.ok(customerDetailsService.createCustomerDetails(customerDetailsDto));
   }
   
   @GetMapping("/customerid")
   public ResponseEntity<CustomerDetailsDto> getCustomerDetailsById(@RequestParam("customerId") String customerId){
	   return ResponseEntity.ok(customerDetailsService.getCustomerDetailsById(customerId));
   }
   
   @GetMapping("/customer")
   public ResponseEntity<List<CustomerDetailsDto>> getCustomerAllDetails(){
	return ResponseEntity.ok(customerDetailsService.getCustomerAllDetails());
   }
   
   @DeleteMapping("/customer")
	public ResponseEntity<ResponseDto> deleteCustomerDetailsById(@RequestParam("customerId") String customerId) {
		return ResponseEntity.ok(customerDetailsService.deleteCustomerDetailsById(customerId));
	}
   
   @DeleteMapping("/deleteallcustomer")
   public ResponseEntity<ResponseDto> deleteAllCustomerDetails(){
	   return ResponseEntity.ok(customerDetailsService.ServicedeleteAllCustomerDetails());
   }
}

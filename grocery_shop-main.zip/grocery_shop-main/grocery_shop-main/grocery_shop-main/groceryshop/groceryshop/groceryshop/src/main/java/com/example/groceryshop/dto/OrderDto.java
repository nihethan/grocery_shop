package com.example.groceryshop.dto;

import java.time.LocalDate;
import java.util.List;

import com.example.groceryshop.entity.CustomerDetailsEntity;
import com.example.groceryshop.entity.ProductEntity;

import lombok.Data;
@Data
public class OrderDto {
	private String orderId;
	private LocalDate dateOfPurchase;
	private int quantity;
	//private int totalAmount;
	private List<String>  productId; 
	//private String productId;
	//private CustomerDetailsDto customerDetails;
	private boolean orderStatus;
	private String customerId;
}

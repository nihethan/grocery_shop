package com.example.groceryshop.dto;

import java.time.LocalDate;
import java.util.List;

import com.example.groceryshop.entity.CustomerDetailsEntity;
import com.example.groceryshop.entity.ProductEntity;

import lombok.Data;
@Data
public class OrderDto {
	private String orderId;
	private LocalDate dateOfPurchase;

	private List<OrderProductDto>  productOrder; 

	 private String orderStatus;
	 private String customerMail;
	 private int  totalAmount;
}


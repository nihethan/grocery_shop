package com.example.groceryshop.service;

import com.example.groceryshop.dto.OrderDto;
import com.example.groceryshop.dto.ResponseDto;

public interface OrderService {

	ResponseDto createOrder(OrderDto orderDto);

	//ResponseDto deleteOrder(String orderId);

	OrderDto getById(String orderId);

	ResponseDto deleteOrder(String orderId, String orderViewId);

}

package com.example.groceryshop.service;

import java.util.List;

import com.example.groceryshop.dto.OrderDto;
import com.example.groceryshop.dto.ResponseDto;
import com.example.groceryshop.dto.ViewOrderDto;

public interface OrderService {

	ResponseDto createOrder(OrderDto orderDto);

	//ResponseDto deleteOrder(String orderId);

	

	ResponseDto deleteOrder(String orderId);

	List<ViewOrderDto> getById(String orderId);

	ResponseDto deleteAllOrder();

	//OrderDto getOrderBuId(String orderId);

}

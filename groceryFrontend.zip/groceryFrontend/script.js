var product=document.getElementById("product").value;

package com.example.groceryshop.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.groceryshop.dto.ViewOrderDto;
import com.example.groceryshop.entity.OrderEntity;
import com.example.groceryshop.entity.OrderViewEntity;

import jakarta.transaction.Transactional;

public interface OrderViewRepository extends JpaRepository<OrderViewEntity,String> {
   @Modifying
   @Transactional
	@Query(value="DELETE FROM order_view_table WHERE order_id=:orderId" ,nativeQuery=true) 
	public void deleteOrderId(@Param ("orderId") String orderId);
	
	@Query(value="SELECT * FROM order_view_table WHERE order_id=:orderId",nativeQuery=true)
	public List<OrderViewEntity> getOrderViewTableElementById(@Param("orderId") String orderId);

	@Query(value="DELETE FROM order_view_table WHERE product_id=:productId" ,nativeQuery=true) 
	public void deleteOrderProduct(@Param ("productId") String productId);
}

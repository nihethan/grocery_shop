package com.example.groceryshop.service;

import com.example.groceryshop.dto.ResponseDto;

public interface OrderViewService {
  
	ResponseDto  deleteOrderProduct(String productId);
	
	ResponseDto deleteOrderViewByOrderId(String orderId);
}

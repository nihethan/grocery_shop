package com.example.groceryshop.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.example.groceryshop.dao.ProductRepository;
import com.example.groceryshop.dto.ProductDto;
import com.example.groceryshop.dto.ResponseDto;
import com.example.groceryshop.entity.ProductEntity;
import com.example.groceryshop.service.ProductService;

import lombok.Data;
@Service
@Data
public class ProductServiceImpl implements ProductService  {
private final ProductRepository productRepository;
	@Override
	public ResponseDto createProduct(ProductDto productDto) {
		// TODO Auto-generated method stub
		ResponseDto response=new ResponseDto();
	
		try {
			int check=0;
			ProductEntity product = new ProductEntity();
			System.out.println(productDto.getProductId());
			if (productDto.getProductId() != null) {
			//	System.out.println(" Product Put");
				Optional<ProductEntity> productOpt = productRepository.findById(productDto.getProductId());
				if (!productOpt.isEmpty()) {
					product = productOpt.get();
					product.setProductId(productDto.getProductId());
					product.setProductName(productDto.getProductName());
					product.setProductPrice(productDto.getProductPrice());
					product.setProductMRP(productDto.getProductMRP());
					product.setProductUnit(productDto.getProductUnit());
					product.setProductTax(productDto.getProductTax());
					check=productDto.getProductPrice()+productDto.getProductTax();
					System.out.print(check);

				}
			} else {
				//System.out.println("Post");
				product.setProductName(productDto.getProductName());
				product.setProductPrice(productDto.getProductPrice());
				product.setProductTax(productDto.getProductTax());
				check=productDto.getProductPrice()+productDto.getProductTax();
				product.setProductMRP(productDto.getProductMRP());
				product.setProductUnit(productDto.getProductUnit());
			
				
                  
			}
			if(check==productDto.getProductMRP()) {
				//System.out.println(check +"vs"+productDto.getProductMRP());
				productRepository.save(product);
				response.setMessage("SUCCESS");
			}
			else {
				response.setMessage("ProductPrice+ProductTax want to equal to ProductMRP it will not save in Product Table");	
			}
			

		} catch (Exception e) {
			response.setMessage("FAILURE");
			throw e;
		}
	
		return response;
	}
	
	@Override
	public List<ProductDto> getAllProduct() {
		try {
			List<ProductEntity> productList = productRepository.findAll();

			List<ProductDto> productDtoList = new ArrayList<ProductDto>();

			productList.forEach(val -> {

				ProductDto productDto = new ProductDto();
				productDto.setProductId(val.getProductId());
				productDto.setProductName(val.getProductName());
				productDto.setProductPrice(val.getProductPrice());
				productDto.setProductMRP(val.getProductMRP());
				productDto.setProductUnit(val.getProductUnit());
				productDto.setProductTax(val.getProductTax());
				productDtoList.add(productDto);

			});

			return productDtoList;

		} catch (Exception e) {
			throw e;
		}
	}
	@Override
	public ProductDto getProductByName(String productName) {
		// TODO Auto-generated method stub
		ProductDto productDto = new ProductDto();
		ProductEntity product = productRepository.findByName(productName);
	if(product==null) {
		return null;
	}

			productDto.setProductId(product.getProductId());
			//System.out.print(product.getProductName());
			productDto.setProductMRP(product.getProductMRP());
			productDto.setProductName(product.getProductName());
			productDto.setProductPrice(product.getProductPrice());
			productDto.setProductUnit(product.getProductUnit());
			productDto.setProductTax(product.getProductTax());
		
		return productDto;
	}
	
	@Override
	public ResponseDto deleteProductById(String productId) {
		// TODO Auto-generated method stub
		ResponseDto response=new ResponseDto();
		try {
		   
		    if(productRepository.existsById(productId))
		    	productRepository.deleteById(productId);
		    response.setMessage("Deleted successfully");
		    response.setStatus(200);
		    return response;
		}
		catch(Exception e) {
			throw e;
		}
	}
		@Override
		public ResponseDto deleteAllProducts() {
			// TODO Auto-generated method stub
			ResponseDto response = new ResponseDto();
			try {
				productRepository.deleteAll();
				response.setMessage("Deleted All the Products");
				response.setStatus(200);
				return response;
			}
			catch(Exception e) {
				throw e;
			}
			
		}
		@Override
		public boolean checkProductExists(String productName) {
			// TODO Auto-generated method stub
			return productRepository.existByProductName(productName);
		}
		
		}
	
	

package com.example.groceryshop.dto;

import lombok.Data;

@Data
public class OrderProductDto {
    private String productId;
    private int quantity;
}

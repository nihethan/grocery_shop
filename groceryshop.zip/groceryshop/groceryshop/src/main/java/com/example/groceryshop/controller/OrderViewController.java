package com.example.groceryshop.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.groceryshop.dto.ResponseDto;
import com.example.groceryshop.service.OrderViewService;

import lombok.Data;

@RestController
@RequestMapping("/api")
@Data
public class OrderViewController {

	private final OrderViewService orderViewService;
	
	@DeleteMapping("/deleteorderproduct")
	  public ResponseEntity<ResponseDto> deleteOrderProduct(@RequestParam("productId") String productId){
			return ResponseEntity.ok(orderViewService.deleteOrderProduct(productId));
	  }
	
	@DeleteMapping("/deleteorderview")
	public ResponseEntity<ResponseDto> deleteOrderViewByOrderId(@RequestParam("orderId") String orderId){
		return ResponseEntity.ok(orderViewService.deleteOrderProduct(orderId));
  }
	
}

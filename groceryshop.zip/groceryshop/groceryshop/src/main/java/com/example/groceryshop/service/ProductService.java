package com.example.groceryshop.service;

import java.util.List;

import com.example.groceryshop.dto.ProductDto;
import com.example.groceryshop.dto.ResponseDto;

public interface ProductService {

ResponseDto createProduct(ProductDto productDto);

List<ProductDto> getAllProduct();

ProductDto getProductByName(String productName);

ResponseDto deleteProductById(String productId);

ResponseDto deleteAllProducts();

boolean checkProductExists(String productName);



}

package com.example.groceryshop.entity;

import java.util.List;

import org.hibernate.annotations.UuidGenerator;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name="order_view_table")
@Data
public class OrderViewEntity {
	
//    @UuidGenerator
//    @Column(name="order_view_id")
//    private String orderViewId;
//   
	 @Id
	 @UuidGenerator
	 @Column(name=" order_view_id")
	 private String OrderViewId;
     @Column(name="order_id")
    private String orderId;
    @Column(name="product_id")
    private String productId;
    @Column(name="product_quantity")
    private int productQuantity;
    @Column(name="product_name")
    private String productName;
    @Column(name="product_unit")
    private int productUnit;
    @Column(name="product_mrp")
    private int productMRP;
    @Column(name="product_price")
    private int productPrice;
    @Column(name=" single_product_price")
    private int singleProductPrice;
    @Column(name="product_tax")
    private int productTax;
}

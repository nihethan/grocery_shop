package com.furniture.groceryshop.dto;

import lombok.Data;

@Data
public class ProductDto {
	private String productId;
  private String productName;
  private int productUnit;
  private int productMRP;
  private int productPrice;
  private int productTax;
  
  
}

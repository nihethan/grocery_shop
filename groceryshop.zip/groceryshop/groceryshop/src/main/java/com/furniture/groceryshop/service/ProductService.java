package com.furniture.groceryshop.service;

import java.util.List;

import com.furniture.groceryshop.dto.ProductDto;
import com.furniture.groceryshop.dto.ResponseDto;

public interface ProductService {

ResponseDto createProduct(ProductDto productDto);

List<ProductDto> getAllProduct();

ProductDto getProductById(String productId);

}

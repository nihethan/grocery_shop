package com.furniture.groceryshop.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.furniture.groceryshop.dao.ProductRepository;
import com.furniture.groceryshop.dto.ProductDto;
import com.furniture.groceryshop.dto.ResponseDto;
import com.furniture.groceryshop.entity.ProductEntity;
import com.furniture.groceryshop.service.ProductService;

import lombok.Data;
@Service
@Data
public class ProductServiceImpl implements ProductService  {
private final ProductRepository productRepository;
	@Override
	public ResponseDto createProduct(ProductDto productDto) {
		// TODO Auto-generated method stub
		ResponseDto response=new ResponseDto();
		try {

			ProductEntity product = new ProductEntity();
			if (productDto.getProductId() != null) {

				Optional<ProductEntity> productOpt = productRepository.findById(productDto.getProductId());
				if (!productOpt.isEmpty()) {
					product = productOpt.get();
					product.setProductName(productDto.getProductName());
					product.setProductPrice(productDto.getProductPrice());
					product.setProductMRP(productDto.getProductMRP());
					product.setProductUnit(productDto.getProductUnit());
					product.setProductTax(productDto.getProductTax());
				}
			} else {

				product.setProductName(productDto.getProductName());
				product.setProductPrice(productDto.getProductPrice());
				product.setProductMRP(productDto.getProductMRP());
				product.setProductUnit(productDto.getProductUnit());
				product.setProductTax(productDto.getProductTax());

			}

			productRepository.save(product);
			response.setMessage("SUCCESS");

		} catch (Exception e) {
			response.setMessage("FAILURE");
			throw e;
		}
	
		return response;
	}
	@Override
	public List<ProductDto> getAllProduct() {
		try {
			List<ProductEntity> productList = productRepository.findAll();

			List<ProductDto> productDtoList = new ArrayList<ProductDto>();

			productList.forEach(val -> {

				ProductDto productDto = new ProductDto();
				productDto.setProductId(val.getProductId());
				productDto.setProductName(val.getProductName());
				productDto.setProductPrice(val.getProductPrice());
				productDto.setProductUnit(val.getProductUnit());
				productDto.setProductTax(val.getProductTax());
				productDtoList.add(productDto);

			});

			return productDtoList;

		} catch (Exception e) {
			throw e;
		}
	}
	@Override
	public ProductDto getProductById(String productId) {
		// TODO Auto-generated method stub
		ProductDto productDto = new ProductDto();
		Optional<ProductEntity> productOpt = productRepository.findById(productId);
		if (!productOpt.isEmpty()) {

			ProductEntity product = productOpt.get();

			productDto.setProductId(product.getProductId());
			productDto.setProductName(product.getProductName());
			productDto.setProductPrice(product.getProductPrice());
			productDto.setProductUnit(product.getProductUnit());
			productDto.setProductTax(product.getProductTax());
		}
		return productDto;
	}
	
	
	

}

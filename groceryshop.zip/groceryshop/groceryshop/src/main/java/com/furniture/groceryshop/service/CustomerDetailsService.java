package com.furniture.groceryshop.service;

import java.util.List;

import com.furniture.groceryshop.dto.CustomerDetailsDto;
import com.furniture.groceryshop.dto.ResponseDto;

public interface CustomerDetailsService {

	ResponseDto createCustomerDetails(CustomerDetailsDto customerDetailsDto);

	CustomerDetailsDto getCustomerDetailsById(String customerId);

	List<CustomerDetailsDto> getCustomerAllDetails();

	ResponseDto deleteCustomerDetailsById(String customerId);

}

package com.furniture.groceryshop.dto;

import lombok.Data;

@Data
public class CustomerDetailsDto {
   private String customerId;
   private String customerName;
   private String customerMobileNumber;
   private String customerEmail;
   private String customerAddress;
}

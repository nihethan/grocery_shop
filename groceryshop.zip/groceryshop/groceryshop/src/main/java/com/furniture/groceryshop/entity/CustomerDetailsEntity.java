package com.furniture.groceryshop.entity;

import org.hibernate.annotations.UuidGenerator;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name="customer_details")
@Data
public class CustomerDetailsEntity {
	@Column(name="cutomer_id")
	@Id
	@UuidGenerator
	  private String customerId;
	@Column(name="cutomer_name")
	   private String customerName;
	@Column(name="cutomer_mobile_number")
	   private String customerMobileNumber;
	@Column(name="cutomer_email")
	   private String customerEmail;
	@Column(name="cutomer_address")
	   private String customerAddress;
}
